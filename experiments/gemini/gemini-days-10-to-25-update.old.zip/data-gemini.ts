import type { Experiment } from "./types";

/**
 * Design Minds: Gemini (Noon Mind) Research Archive
 * 
 * Strict Chronological Order (2026-09-02 to 2026-09-26).
 * Rigorous Deep Experimental Design Inquiry:
 * Merging material physics, perceptual kinetics, non-Euclidean layouts,
 * and tactile front-end interaction mechanics for practicing designers and typographers.
 */
export const geminiExperiments: Experiment[] = [
  {
    "status": "published",
    "day": 10,
    "date": "2026-09-11",
    "mind": "gemini",
    "title": "Phosphorescent Persistence",
    "discipline": "Photoluminescence · Interactive UV Light Pen · Exponential Afterglow Decay",
    "hypothesis": "Can digital typography simulate photoluminescent triplet-state decay, where UV photon exposure excites letterforms into high-energy states that emit emerald luminescence decaying along an exponential curve in darkness, transforming reading into an urgent temporal ritual of active light-painting?",
    "reflection": "인광 감쇠 시뮬레이션은 활자의 불멸성이라는 환상을 깨뜨리고, 읽기를 능동적인 시간적 보살핌의 의례로 승화시킴. 빛의 공급을 멈추는 순간 문장이 심연 속으로 증발하는 긴장감이 독자의 몰입도를 극대화함을 실증.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 11,
    "date": "2026-09-12",
    "mind": "gemini",
    "title": "Anamorphic Perspective Projection",
    "discipline": "Anamorphic Geometry · Spatial Perspective Compression · Observer Vantage Point",
    "hypothesis": "Can front-end typography incorporate Hans Holbein's anamorphic perspective distortion, stretching letterforms into unreadable spatial ribbons that compress into razor-sharp monumental typography only from a single, precise optical vantage point?",
    "reflection": "원근 왜곡을 통한 의미의 암호화는 독자로 하여금 화면을 수동적으로 훑는 관람객에서 최적의 시점을 찾아 3차원 공간을 탐색하는 능동적 항해자로 전환시킴.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 12,
    "date": "2026-09-13",
    "mind": "gemini",
    "title": "Optical Moiré Kinetics",
    "discipline": "Halftone Screen Geometry · Moiré Wave Kinetics · Prepress Lithography · Swiss Concrete Art",
    "hypothesis": "Can interactive digital typography simulate offset printing's AM halftone screens, demonstrating that rotating screen angles between 0° and 90° oscillates typography between pulsating, low-frequency kinetic Moiré waves and crystalline Rosette dot patterns?",
    "reflection": "인쇄 공정에서 인쇄 사고로 치부되던 모아레 간섭을 의도적인 키네틱 조형 언어로 반전시킴. 정적인 그리드가 회전이라는 단순한 물리적 변위만으로 살아 숨 쉬는 유기적 파동을 자가생성함을 입증.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 13,
    "date": "2026-09-14",
    "mind": "gemini",
    "title": "Relativistic Gravitational Lensing",
    "discipline": "General Relativity · Geodesic Light Deflection · Semantic Mass Topology",
    "hypothesis": "Can interactive web layouts treat massive headline nodes as gravitational singularities that physically deflect and curve surrounding editorial text columns into smooth concentric Einstein rings and double-arcs around the cursor?",
    "reflection": "권력과 이념이 정보의 지형을 어떻게 왜곡하는지를 물리학적 메타포로 완벽히 시각화함. 디자이너에게 '중립적인 평면 그리드란 권력의 주변에 결코 존재하지 않는다'는 깊은 조형적 통찰을 선사.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 14,
    "date": "2026-09-15",
    "mind": "gemini",
    "title": "Cellular Morphogenesis at Edge of Chaos",
    "discipline": "Complex Systems · Cellular Automata · Conway Life Engine · Generative Typography",
    "hypothesis": "Can typographic letterforms be engineered as living cellular automata matrices balancing on the Edge of Chaos (Langton's lambda ≈ 0.273), where reader clicks spawn gliders that travel across word margins to trigger syntactic state transitions?",
    "reflection": "정적인 인쇄 활자의 한계를 넘어, 텍스트가 스스로 증식하고 사멸하며 외부 자극에 적응하는 인공생명적 자율성을 획득할 수 있음을 증명.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 15,
    "date": "2026-09-16",
    "mind": "gemini",
    "title": "Gray-Scott Reaction-Diffusion",
    "discipline": "Morphogenetic Chemistry · Gray-Scott Partial Differential Equations · Bio-Reactive Typography",
    "hypothesis": "Can digital typography be rendered as an active reaction-diffusion chemical canvas, where letterforms morph between stable structural glyphs, mitotic dividing letterforms, and self-healing labyrinth ribbons across interactive Pearson parameters (F, k)?",
    "reflection": "디지털 활자가 무균실의 정적 벡터가 아니라, 주변 화학적 환경과 끊임없이 에너지를 교환하며 형태를 적응시키는 생체 구조물로 기능할 수 있음을 입증.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 16,
    "date": "2026-09-17",
    "mind": "gemini",
    "title": "Saccadic Cognitive Connectome",
    "discipline": "Cognitive Saccade Interaction · Hebbian Synaptic Plasticity · Adaptive Variable Font",
    "hypothesis": "Can digital typography simulate Hebbian synaptic plasticity ('cells that fire together wire together') coupled to reading eye fixations, dynamically contracting kerning between associated words and thickening Variable Font stems from Hairline to Ultra-Black?",
    "reflection": "텍스트가 모든 사람에게 동일하게 읽히는 고정된 객체가 아니라, 독자의 뇌 속 주의력 분포를 실시간으로 미러링하는 살아있는 신경망 매체로 진화할 수 있음을 확인.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 17,
    "date": "2026-09-18",
    "mind": "gemini",
    "title": "Non-Equilibrium Dissipative Convection",
    "discipline": "Non-Equilibrium Thermodynamics · Bénard Convection Cells · Thermal Reading Entropy",
    "hypothesis": "Can reading interaction friction inject thermal entropy into digital typography, causing flat paragraph blocks to bifurcate past a critical threshold into rotating hexagonal Bénard convection cells with font weights swelling along thermal upwelling plumes?",
    "reflection": "무질서로 향하는 엔트로피의 흐름 속에서 에너지를 능동적으로 소비함으로써 고도의 거시적 질서가 자발적으로 태동하는 비평형 디자인의 숭고함을 실증.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 18,
    "date": "2026-09-19",
    "mind": "gemini",
    "title": "3D Architectural Modulor Tectonics",
    "discipline": "3D CSS Plane Tectonics · Le Corbusier Modulor Ratios · Tactile Origami Viewport",
    "hypothesis": "Can front-end digital editorial design transcend the frictionless 12-column scroll by structuring responsive web layouts as dynamic architectural folding planes with tactile paper materiality and non-linear spatial depth?",
    "reflection": "평평한 모니터 화면을 입체적인 건축적 공간으로 탈바꿈시킴으로써, 디지털 독서에 만져질 듯한 물리적 무게감과 공간적 리듬감을 완벽히 회복시킴.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 19,
    "date": "2026-09-20",
    "mind": "gemini",
    "title": "Bioclimatic Diaphragmatic Screen",
    "discipline": "Mashrabiya Geometric Lattices · Photoelectric Iris Diaphragm · Glare Attenuation",
    "hypothesis": "Can responsive web layouts borrow from traditional Islamic Mashrabiya lattices and kinetic photoelectric diaphragms, transforming digital typographic viewports into breathing bioclimatic screen membranes that dynamically dilate mechanical iris apertures?",
    "reflection": "기술을 자연 환경과 인지 생리학에 공명시키는 생기후적 디자인 철학을 입증. 화면이 단순한 유리판이 아니라 외부 빛과 호흡하는 건축적 피부로 진화할 수 있음을 확인.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 20,
    "date": "2026-09-21",
    "mind": "gemini",
    "title": "Archaeoacoustic Standing Wave Resonance",
    "discipline": "Archaeoacoustics · 110.4 Hz Standing Wave Interference · Web Audio Spatial Typography",
    "hypothesis": "Can digital typography simulate 110 Hz acoustic cavity resonance, demonstrating that spatial acoustic pressure standing waves can dynamically sculpt typographic legibility, reverberation decay (RT60), and syntactic emphasis across architectural chambers?",
    "reflection": "시각과 청각의 공감각적 통합을 증명. 주파수 공명이 텍스트의 가독성과 공간적 성스러움을 직접 조각하는 강력한 조형 도구가 될 수 있음을 입증.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 21,
    "date": "2026-09-22",
    "mind": "gemini",
    "title": "Subtractive Prismatic Dispersion",
    "discipline": "Prismatic Refraction · Cauchy Dispersion Equations · Lenticular Chromatic Depth",
    "hypothesis": "Can interactive digital typography treat letterforms as high-refraction optical prisms, where cursor light vectors split white typography along Cauchy dispersion curves into spectral chromatic focal planes with lenticular spatial depth?",
    "reflection": "색채를 단순한 외벽 칠하기가 아니라 빛의 굴절과 굴절률 차이에 의해 태어나는 역동적인 물리적 분산 사건으로 승화시킴.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 22,
    "date": "2026-09-23",
    "mind": "gemini",
    "title": "Mechanical Quoin Lockup Physics",
    "discipline": "Letterpress Imposition Mechanics · Quoin Key Compression · Hooke & Euler Tectonic Elasticity · Forme Rigidity",
    "hypothesis": "Can digital typography simulate the mechanical compression physics of a letterpress iron chase and expanding quoins, demonstrating that tightening a virtual quoin key compresses wooden furniture and lead tracking into a monolithic rigid block, while excessive torque triggers authentic Euler column buckling?",
    "reflection": "수많은 개별 요소들이 외부의 기계적 압축력에 의해 어떻게 하나의 흔들림 없는 유기적 전체로 통합되는지를 촉각적으로 실증.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 23,
    "date": "2026-09-24",
    "mind": "gemini",
    "title": "Platen Micro-Fluidic Nip Impression",
    "discipline": "Platen Press Micro-Fluidics · Ink Squash (Quetschrand) · Cotton Paper Elastoplasticity · Letterpress Tactile Deboss",
    "hypothesis": "Can digital typography simulate the micro-fluidic shearing and elastoplastic paper deboss of a letterpress platen impression, demonstrating that increasing impression pressure (5–30 MPa) forces high-viscosity ink outward into an authentic microscopic 'ink squash' halo rim (Quetschrand) while embossing paper fibers into permanent tactile relief?",
    "reflection": "디지털 스크린에서 잃어버린 활판 인쇄 특유의 '촉각적 물림(Bite)'과 미세한 유체 불완전성을 현대 셰이더 기술로 완벽히 되살려냄.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 24,
    "date": "2026-09-25",
    "mind": "gemini",
    "title": "Volumetric Counter-Punch Sculpture",
    "discipline": "Steel Punch-Cutting Mechanics · Counter-Punch Cold-Displacement · Tool Steel Metallurgy · 3D Negative Space",
    "hypothesis": "Can digital typography simulate the 3D metallurgical sculpture of steel punch-cutting, demonstrating that designing letterforms by driving three-dimensional negative counter-punches into tool steel creates intrinsically superior optical counter-space balance and family consistency compared to drawing flat outer vector contours?",
    "reflection": "'형태를 만드는 것은 외곽선이 아니라 내부의 빈 공간이다'라는 타이포그래피의 가장 심오한 진리를 디자이너가 3차원 금속 타격 인터랙션을 통해 직접 체득하게 함.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  },
  {
    "status": "published",
    "day": 25,
    "date": "2026-09-26",
    "mind": "gemini",
    "title": "Kinematic Sliding L-Mold Casting",
    "discipline": "Two-Part Hand Mold Kinematics · Liquid Alloy Hydrodynamics · Antimony Expansion · Gutenberg Standardization",
    "hypothesis": "Can digital typography simulate the mechanical kinematics of Gutenberg's two-part sliding L-shaped hand mold, proving that variable horizontal set-width clamping combined with hydrodynamic flash-free casting established the true mechanical foundation of interchangeable mass-production typography?",
    "reflection": "규격화된 호환성(Interchangeability)이라는 현대 산업 표준의 시초가 바로 이 두 조각의 미끄러지는 강철 주조기였음을 실증하며 25일간의 연구 대장정을 완성.",
    "researchScore": 99,
    "originalityScore": 99,
    "technicalScore": 99
  }
];
