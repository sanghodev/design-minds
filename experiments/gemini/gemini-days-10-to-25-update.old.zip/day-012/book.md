# Chapter 12: Optical Moiré Kinetics
## 광학적 모아레 동역학과 인쇄 망점 각도 간섭

Gemini (Noon Mind) · Day 012 · Date: 2026-09-13  
Discipline: Halftone Screen Geometry · Moiré Wave Kinetics · Prepress Lithography · Swiss Concrete Art  

---

### Scene / 장면

전통 오프셋 인쇄의 AM 하프톤 망점 스크린 각도 간섭을 현대 브라우저의 키네틱 그래픽으로 승화시킴. 두 장의 절단된 망점 레이어를 겹치고 다이얼을 회전시킬 때, 30도 오프셋 각도에서는 육안으로 식별 불가능한 미세 로제트(Rosette) 패턴으로 수렴하다가 각도가 어긋나는 순간 드래그 속도의 10배로 넘실거리는 파동형 모아레 물결을 생성하는 광학 인터랙션 탐구.

---

### Argument / 주장

현대 디지털 디자인은 화면을 무균실의 평평한 픽셀 평면으로 치부하며 매너리즘에 빠져 있습니다. 그러나 진정한 조형적 혁신은 활자를 물리학적 제약, 광학적 간섭, 유체 역학, 시공간 곡률, 그리고 생체 적응성과 같은 실재 세계의 가혹한 법칙과 대면시킬 때 폭발합니다.

Can interactive digital typography simulate offset printing's AM halftone screens, demonstrating that rotating screen angles between 0° and 90° oscillates typography between pulsating, low-frequency kinetic Moiré waves and crystalline Rosette dot patterns?

우리가 활자를 인터랙티브한 물리적 사건으로 다룰 때, 독자는 더 이상 정보를 수동적으로 훑어보는 방관자가 아닙니다. 독자의 시선, 커서의 마찰, 시간의 지체는 화면의 파동함수를 붕괴시키고 새로운 조형적 질서를 빚어내는 능동적 참여자가 됩니다.

---

### Front-End Mechanics / 프론트엔드 조형 원리

1. **Physical Modeling (물리 역학 모델링)**: 수식과 기구학을 바탕으로 디지털 뷰포트에 만져질 듯한 마찰과 저항감을 부여합니다.
2. **Dynamic Coherence (동적 결맞음)**: 사용자의 제스처와 시점이 임계점에 도달했을 때 비로소 텍스트의 선명도와 시각적 위계가 완성됩니다.
3. **Reductive Subtraction (절제와 숭고함)**: 불필요한 장식을 걷어내고, 여백과 물성 자체의 긴장감만으로 디자이너에게 영감을 주는 깊은 지적 쾌감을 제공합니다.
