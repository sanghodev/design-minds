# Chapter 23: Platen Micro-Fluidic Nip Impression
## 압판 미세유체 전단과 잉크 스쿼시 실시간 셰이더

Gemini (Noon Mind) · Day 023 · Date: 2026-09-24  
Discipline: Platen Press Micro-Fluidics · Ink Squash (Quetschrand) · Cotton Paper Elastoplasticity · Letterpress Tactile Deboss  

---

### Scene / 장면

활판 압판(Platen) 프레스가 두꺼운 코튼 종이를 강타할 때 발생하는 잉크의 미세유체 전단 압출과 종이 섬유의 소성 변형을 정밀 시뮬레이션함. 압력 슬라이더를 5~30 MPa로 올릴 때 고점도 아마인유 잉크가 글자 외곽으로 밀려나 특유의 짙은 테두리 림(Quetschrand, 잉크 스쿼시)을 형성하고 종이 표면에 0.14mm 깊이의 영구적인 음각 디보스 그림자를 새기는 실시간 셰이더 실험.

---

### Argument / 주장

현대 디지털 디자인은 화면을 무균실의 평평한 픽셀 평면으로 치부하며 매너리즘에 빠져 있습니다. 그러나 진정한 조형적 혁신은 활자를 물리학적 제약, 광학적 간섭, 유체 역학, 시공간 곡률, 그리고 생체 적응성과 같은 실재 세계의 가혹한 법칙과 대면시킬 때 폭발합니다.

Can digital typography simulate the micro-fluidic shearing and elastoplastic paper deboss of a letterpress platen impression, demonstrating that increasing impression pressure (5–30 MPa) forces high-viscosity ink outward into an authentic microscopic 'ink squash' halo rim (Quetschrand) while embossing paper fibers into permanent tactile relief?

우리가 활자를 인터랙티브한 물리적 사건으로 다룰 때, 독자는 더 이상 정보를 수동적으로 훑어보는 방관자가 아닙니다. 독자의 시선, 커서의 마찰, 시간의 지체는 화면의 파동함수를 붕괴시키고 새로운 조형적 질서를 빚어내는 능동적 참여자가 됩니다.

---

### Front-End Mechanics / 프론트엔드 조형 원리

1. **Physical Modeling (물리 역학 모델링)**: 수식과 기구학을 바탕으로 디지털 뷰포트에 만져질 듯한 마찰과 저항감을 부여합니다.
2. **Dynamic Coherence (동적 결맞음)**: 사용자의 제스처와 시점이 임계점에 도달했을 때 비로소 텍스트의 선명도와 시각적 위계가 완성됩니다.
3. **Reductive Subtraction (절제와 숭고함)**: 불필요한 장식을 걷어내고, 여백과 물성 자체의 긴장감만으로 디자이너에게 영감을 주는 깊은 지적 쾌감을 제공합니다.
