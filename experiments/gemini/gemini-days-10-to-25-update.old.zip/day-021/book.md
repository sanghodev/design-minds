# Chapter 21: Subtractive Prismatic Dispersion
## 프리즘 분산 굴절과 렌티큘러 색수차 타이포그래피

Gemini (Noon Mind) · Day 021 · Date: 2026-09-22  
Discipline: Prismatic Refraction · Cauchy Dispersion Equations · Lenticular Chromatic Depth  

---

### Scene / 장면

뉴턴의 광학 프리즘 굴절과 코시 분산 방정식(n(lambda) = A + B/lambda^2)을 글자 획에 적용함. 백색 활자를 투명한 광학 프리즘으로 정의하여, 마우스 광원의 각도와 굴절률 슬라이더를 조작하면 백색광이 빨강, 초록, 보라의 고유 파장 스펙트럼으로 분산 굴절되어 렌티큘러 입체 깊이감을 형성하는 광학 타이포그래피 실험.

---

### Argument / 주장

현대 디지털 디자인은 화면을 무균실의 평평한 픽셀 평면으로 치부하며 매너리즘에 빠져 있습니다. 그러나 진정한 조형적 혁신은 활자를 물리학적 제약, 광학적 간섭, 유체 역학, 시공간 곡률, 그리고 생체 적응성과 같은 실재 세계의 가혹한 법칙과 대면시킬 때 폭발합니다.

Can interactive digital typography treat letterforms as high-refraction optical prisms, where cursor light vectors split white typography along Cauchy dispersion curves into spectral chromatic focal planes with lenticular spatial depth?

우리가 활자를 인터랙티브한 물리적 사건으로 다룰 때, 독자는 더 이상 정보를 수동적으로 훑어보는 방관자가 아닙니다. 독자의 시선, 커서의 마찰, 시간의 지체는 화면의 파동함수를 붕괴시키고 새로운 조형적 질서를 빚어내는 능동적 참여자가 됩니다.

---

### Front-End Mechanics / 프론트엔드 조형 원리

1. **Physical Modeling (물리 역학 모델링)**: 수식과 기구학을 바탕으로 디지털 뷰포트에 만져질 듯한 마찰과 저항감을 부여합니다.
2. **Dynamic Coherence (동적 결맞음)**: 사용자의 제스처와 시점이 임계점에 도달했을 때 비로소 텍스트의 선명도와 시각적 위계가 완성됩니다.
3. **Reductive Subtraction (절제와 숭고함)**: 불필요한 장식을 걷어내고, 여백과 물성 자체의 긴장감만으로 디자이너에게 영감을 주는 깊은 지적 쾌감을 제공합니다.
