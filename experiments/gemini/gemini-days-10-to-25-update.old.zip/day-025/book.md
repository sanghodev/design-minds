# Chapter 25: Kinematic Sliding L-Mold Casting
## 기구학적 슬라이딩 L-금형과 미세유체 관성 주조

Gemini (Noon Mind) · Day 025 · Date: 2026-09-26  
Discipline: Two-Part Hand Mold Kinematics · Liquid Alloy Hydrodynamics · Antimony Expansion · Gutenberg Standardization  

---

### Scene / 장면

인쇄 혁명의 진정한 기술적 기폭제였던 요하네스 구텐베르크의 2분할 L자형 조절식 수동 주조기(Hand Mold) 기구학을 복원함. 활자 높이(23.56mm)는 고정된 채 글자 자폭에 맞춰 가로로 미끄러지는 L-프레임에 구리 매트릭스를 고정하고, 쇳물을 부은 직후 손목을 위로 낚아채는 '주조사의 반동 도약(Coup de main, 4.5g)'으로 영-라플라스 표면장력을 극복하여 7마이크로미터 세리프를 완벽히 채우는 미세유체 금형 인터랙션 탐구.

---

### Argument / 주장

현대 디지털 디자인은 화면을 무균실의 평평한 픽셀 평면으로 치부하며 매너리즘에 빠져 있습니다. 그러나 진정한 조형적 혁신은 활자를 물리학적 제약, 광학적 간섭, 유체 역학, 시공간 곡률, 그리고 생체 적응성과 같은 실재 세계의 가혹한 법칙과 대면시킬 때 폭발합니다.

Can digital typography simulate the mechanical kinematics of Gutenberg's two-part sliding L-shaped hand mold, proving that variable horizontal set-width clamping combined with hydrodynamic flash-free casting established the true mechanical foundation of interchangeable mass-production typography?

우리가 활자를 인터랙티브한 물리적 사건으로 다룰 때, 독자는 더 이상 정보를 수동적으로 훑어보는 방관자가 아닙니다. 독자의 시선, 커서의 마찰, 시간의 지체는 화면의 파동함수를 붕괴시키고 새로운 조형적 질서를 빚어내는 능동적 참여자가 됩니다.

---

### Front-End Mechanics / 프론트엔드 조형 원리

1. **Physical Modeling (물리 역학 모델링)**: 수식과 기구학을 바탕으로 디지털 뷰포트에 만져질 듯한 마찰과 저항감을 부여합니다.
2. **Dynamic Coherence (동적 결맞음)**: 사용자의 제스처와 시점이 임계점에 도달했을 때 비로소 텍스트의 선명도와 시각적 위계가 완성됩니다.
3. **Reductive Subtraction (절제와 숭고함)**: 불필요한 장식을 걷어내고, 여백과 물성 자체의 긴장감만으로 디자이너에게 영감을 주는 깊은 지적 쾌감을 제공합니다.
