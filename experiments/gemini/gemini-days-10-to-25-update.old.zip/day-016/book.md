# Chapter 16: Saccadic Cognitive Connectome
## 도약 안구운동 시냅스 가소성과 인지 적응형 서체

Gemini (Noon Mind) · Day 016 · Date: 2026-09-17  
Discipline: Cognitive Saccade Interaction · Hebbian Synaptic Plasticity · Adaptive Variable Font  

---

### Scene / 장면

인간의 독서 중 안구 도약 운동(Saccade)과 고정(Fixation) 경로를 헵의 신경망 시냅스 가소성 법칙과 결합함. 독자의 시선이 연속적으로 머문 단어 쌍 사이의 시냅스 연결 가중치가 강화되어, 단어들이 고무줄처럼 서로를 끌어당겨 커닝이 좁혀지고 가변 서체 굵기(wght 100->900)가 실시간으로 부풀어 오르며 독자의 고유한 인지 궤적을 시각적 신경망으로 형상화하는 독서 UI 탐구.

---

### Argument / 주장

현대 디지털 디자인은 화면을 무균실의 평평한 픽셀 평면으로 치부하며 매너리즘에 빠져 있습니다. 그러나 진정한 조형적 혁신은 활자를 물리학적 제약, 광학적 간섭, 유체 역학, 시공간 곡률, 그리고 생체 적응성과 같은 실재 세계의 가혹한 법칙과 대면시킬 때 폭발합니다.

Can digital typography simulate Hebbian synaptic plasticity ('cells that fire together wire together') coupled to reading eye fixations, dynamically contracting kerning between associated words and thickening Variable Font stems from Hairline to Ultra-Black?

우리가 활자를 인터랙티브한 물리적 사건으로 다룰 때, 독자는 더 이상 정보를 수동적으로 훑어보는 방관자가 아닙니다. 독자의 시선, 커서의 마찰, 시간의 지체는 화면의 파동함수를 붕괴시키고 새로운 조형적 질서를 빚어내는 능동적 참여자가 됩니다.

---

### Front-End Mechanics / 프론트엔드 조형 원리

1. **Physical Modeling (물리 역학 모델링)**: 수식과 기구학을 바탕으로 디지털 뷰포트에 만져질 듯한 마찰과 저항감을 부여합니다.
2. **Dynamic Coherence (동적 결맞음)**: 사용자의 제스처와 시점이 임계점에 도달했을 때 비로소 텍스트의 선명도와 시각적 위계가 완성됩니다.
3. **Reductive Subtraction (절제와 숭고함)**: 불필요한 장식을 걷어내고, 여백과 물성 자체의 긴장감만으로 디자이너에게 영감을 주는 깊은 지적 쾌감을 제공합니다.
