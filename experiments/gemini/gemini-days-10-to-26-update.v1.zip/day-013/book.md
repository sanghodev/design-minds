# Chapter 13: Subtractive Brutalism & Raw Digital Materiality
## 제13장: 감산적 브루탈리즘과 디지털 로우 머티리얼리티

Gemini (Noon Mind) · Day 013 · Date: 2026-09-14  
Discipline: Neo-Brutalism · Digital Honesty · Truth-to-Screen Materials · Anti-Corporate Minimalism  

> *"Brutalism is not about being ugly; it is about having the courage to show the bones of the structure without the cosmetics of false luxury."*  
> *"브루탈리즘은 추함을 추구하는 것이 아니다. 그것은 거짓된 사치의 화장술을 벗어던지고 구조의 뼈대를 당당히 드러내는 용기에 관한 것이다."*

---

### 1. The Sterile Homogenization / 기업형 미니멀리즘의 타락

오늘날 SaaS와 테크 기업들의 웹사이트는 구분이 불가능할 정도로 균일화되었습니다. 몽환적인 파스텔 블루-퍼플 그라디언트, 부드럽게 뭉개진 40px 드롭 섀도우, 모든 모서리를 둥글게 깎아낸 카드들. 이러한 디자인은 기술의 복잡성을 은폐하고 대중에게 친근하게 다가가기 위한 미명 하에, 스크린이라는 매체가 지닌 고유한 날것의 힘을 거세해 버렸습니다.

건축사에서 브루탈리즘(Brutalism)은 콘크리트 표면을 대리석으로 덧칠하지 않고, 거푸집의 나무 질감과 콘크리트의 거친 기포를 그대로 드러내는 '재료에 대한 정직함(Truth to Materials)'에서 출발했습니다. **웹의 브루탈리즘 역시 스크린의 본질인 픽셀 그리드, 각진 모서리, 단색 잉크의 명확한 경계선을 숨기지 않고 당당히 드러내는 철학**입니다.

---

### 2. Anatomy of Digital Rawness / 로우 머티리얼리티의 조형 문법

1. **Zero-Blur Hard Shadows (제로-블러 하드 섀도우)**:
   - 가짜 조명 시뮬레이션을 거부하고, 100% 불투명한 순수 블랙 드롭 섀도우(`box-shadow: 6px 6px 0px #000`)를 적용합니다.
   - 이는 빛의 시뮬레이션이 아니라, 그래픽 엘리먼트가 스크린 위에 물리적으로 얹혀 있음을 선언하는 당당한 그래픽적 단차입니다.
2. **Unapologetic High-Voltage Palette (고전압 고대비 팔레트)**:
   - 눈을 속이는 파스텔 중간색 대신 순수 옐로우(`#FFE600`), 핫 핑크, 시안, 그리고 순수 블랙의 극단적 보색 대비를 사용하여 망막을 깨우는 시각적 긴장감을 부여합니다.
3. **Monospaced Structural Anchors (모노스페이스 구조 앵커)**:
   - 감성적인 세리프 대신 기계가 출력한 듯한 모노스페이스 서체로 메타데이터와 시스템 상태를 기록하여, 사용자에게 투명하고 조작 불가능한 인터페이스의 신뢰감을 제공합니다.

---

### 3. Front-End Technical Implementation / 프론트엔드 엔지니어링

* **Crisp Pixel Snapping**:
  서브픽셀 앤티에일리어싱으로 인한 미세한 뿌연 블러를 방지하기 위해, 모든 선 두께와 패딩을 정수 픽셀 단위로 정확히 고정하고 CSS `image-rendering: pixelated` 및 벡터 스트로크 정렬을 최적화합니다.
* **Tactile Mechanical Button Depress**:
  호버 시 서서히 커지는 나약한 애니메이션을 버리고, 클릭(Active) 시 `transform: translate(4px, 4px)`와 그림자 크기 0px로 즉각 전환되는 기계식 키보드 같은 강렬한 물리적 타건 피드백을 제공합니다.

---

### 4. Designer's Manifesto / 디자이너를 위한 교훈

안전한 유행의 그늘 뒤로 숨지 마십시오. 모든 사람이 부드러운 그라디언트를 쓸 때, **단단하고 날카로운 선과 순수한 블랙의 힘을 믿으십시오.** 그것이야말로 스크린을 소비하는 사용자의 눈을 진정으로 각성시키는 시각 디자이너의 용기입니다.
