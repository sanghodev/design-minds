# Chapter 10: Scroll-Driven Spatial Choreography & View Transitions
## 제10장: 스크롤 기반 공간 안무와 뷰 트랜지션의 연속성

Gemini (Noon Mind) · Day 010 · Date: 2026-09-11  
Discipline: Temporal Layout Architecture · CSS animation-timeline · View Transitions API · Cinematic Choreography  

> *"The web is not a series of static slides bound together by hyperlinks; it is a continuous camera move through an infinite architectural space."*  
> *"웹은 하이퍼링크로 엮인 정적 슬라이드의 나열이 아니다. 그것은 무한한 건축적 공간을 가로지르는 하나의 연속된 카메라 이동이다."*

---

### 1. The Death of the 'Page' / '페이지'라는 환상의 종말

지난 30년간 웹 디자인은 구텐베르크의 '종이 책'이라는 은유에 갇혀 있었습니다. 주소창의 URL이 바뀌면 화면이 흰색으로 깜빡이고, 이전 페이지의 요소들은 산산조각 나며 새로운 문서가 불쑥 나타납니다. 이러한 '페이지 단위의 단절(Page Boundary Fragmentation)'은 사용자의 인지 연속성을 끊임없이 파괴해 왔습니다.

그러나 현대 브라우저는 GPU 가속 기반의 `View Transitions API`와 CSS `animation-timeline: scroll() / view()`를 통해 브라우저를 하나의 유기적인 시네마틱 렌더링 파이프라인으로 진화시켰습니다. 이제 디자인의 단위는 '정적 페이지'가 아니라 **'시간과 스크롤에 종속된 공간 안무(Spatial Choreography)'**가 됩니다.

---

### 2. Theoretical Architecture / 공간 안무의 조형 원리

1. **Spatial Persistence (시각적 영속성)**:
   - 목록에서 상세 화면으로 넘어갈 때, 카드의 썸네일과 타이틀은 사라지는 것이 아니라 화면 상단으로 비행하며 헤더의 영구적인 닻(Anchor)으로 스스로를 재배치합니다.
   - 독자는 정보의 위치를 뇌 속에서 재구성할 필요 없이, 시선의 연속적인 흐름을 유지할 수 있습니다.
2. **Kinetic Parallax & Depth Cues (시차와 공간 깊이감)**:
   - 전경의 헤드라인, 중경의 에디토리얼 칼럼, 배경의 기하학적 앰비언트 메쉬가 스크롤 속도에 따라 각기 다른 관성($v_1, v_2, v_3$)으로 흐르며 평면 스크린 위에 3차원 공간 텍토닉스를 형성합니다.
3. **Scroll as Scrubbing Timeline (시간 축으로서의 스크롤)**:
   - 사용자의 스크롤 제스처는 물리적 휠 돌림이 아니라, 비디오 편집기의 타임라인을 앞뒤로 스크러빙하는 행위와 같습니다. 요소의 등장, 변형, 퇴장은 정확한 시차 곡선에 맞춰 안무가 연출되듯 펼쳐집니다.

---

### 3. Front-End Technical Implementation / 프론트엔드 엔지니어링

* **CSS Container Queries & Animation Timelines**:
  자바스크립트 스크롤 리스너의 연산 오버헤드 없이, 브라우저 컴포지터 스레드(Compositor Thread)에서 직접 실행되는 순수 CSS `@keyframes`와 `view()` 타임라인을 결합하여 60fps 무지연 버터 스크롤을 구현합니다.
* **View Transition Morphing**:
  `view-transition-name` 속성을 통해 DOM 구조가 완전히 다른 두 상태 사이에서 엘리먼트의 기하학적 크기와 위치, 보더 라디우스를 수학적 선형 보간(FLIP)으로 매끄럽게 모핑합니다.

---

### 4. Designer's Manifesto / 디자이너를 위한 교훈

더 이상 화면을 고정된 '캔버스'로 디자인하지 마십시오. 디자인해야 할 대상은 **화면이 전환되는 바로 그 찰나의 시간과 궤적**입니다. 훌륭한 시각 디자이너는 이제 그래픽 아티스트이자 동시에 공간의 카메라 감독이어야 합니다.
