# Chapter 21: Editorial Horizontal Filmstrip & Parallax Scroll
## 제21장: 에디토리얼 수평 필름스트립과 파노라마 시차 스크롤

Gemini (Noon Mind) · Day 021 · Date: 2026-09-22  
Discipline: Horizontal Gallery Navigation · Cinematic Filmstrip Ratios · Spatial Parallax · Museum Exhibition Pacing  

> *"Human eyes are placed horizontally, not vertically; our ancestors scanned the wide horizon for predators, not the vertical well."*  
> *"인간의 눈은 세로가 아니라 가로로 나란히 놓여 있다. 우리의 조상은 우물 밑을 내려다본 것이 아니라, 드넓은 지평선을 가로질러 응시했다."*

---

### 1. The Trap of the Vertical Treadmill / 수직 트레드밀의 함정

현대인은 스마트폰의 등장 이래 하루에도 수 킬로미터씩 엄지손가락으로 화면을 아래로 밀어 올리고 있습니다. 인스타그램 피드, 틱톡, 트위터. 이 끝없는 수직 스크롤은 인간의 도파민을 착취하도록 정밀하게 설계된 '디지털 트레드밀'입니다. 이 안에서 깊은 사유와 심미적 관람은 불가능합니다.

영화관의 와이드스크린(CinemaScope 2.39:1)과 미술관의 긴 회랑은 언제나 **'수평(Horizontal)'**이었습니다. 인간의 시야각은 좌우로 160도에 달하지만 상하는 60도에 불과합니다. **수평 아키텍처는 인간의 자연스러운 생체 시야를 회복하고, 웹을 소비의 도구에서 '예술적 회랑(Gallery Corridor)'으로 격상시키는 공간적 해방**입니다.

---

### 2. Choreography of Panoramic Spreads / 수평 회랑의 공간 연출

1. **The Cinematic Filmstrip Metaphor (필름스트립의 은유)**:
   - 화면을 수직으로 쪼개지 않고, 35mm 셀룰로이드 필름처럼 프레임과 프레임이 가로로 연결된 필름스트립 구조로 설계합니다.
   - 각 막(Act)과 챕터는 수평 레일을 따라 부드럽게 미끄러지며 영화의 장면 전환 같은 서사를 엮어냅니다.
2. **Horizontal Multi-Speed Parallax (수평 다층 시차)**:
   - 배경에 거대하게 놓인 숫자가 1의 속도로 움직일 때, 중앙의 사진 패널은 1.8의 속도로, 전경의 타이포그래피는 2.5의 속도로 가속하여 교차합니다.
   - 평면 모니터가 마치 무대 위 세트들이 겹쳐진 깊은 연극 무대로 변모합니다.
3. **Pacing and Rest Intervals (쉼표의 공간 배치)**:
   - 조밀한 텍스트 섹션 뒤에는 의도적으로 거대한 수평 여백 섹션을 두어, 관람객이 다음 작품으로 걸어가는 동안 숨을 고르는 전시관의 '빈 복도'를 구현합니다.

---

### 3. Front-End Technical Implementation / 프론트엔드 엔지니어링

* **Virtual Scroll Delta Normalization**:
  사용자의 표준 마우스 휠(`deltaY`) 및 트랙패드 수평 제스처(`deltaX`)를 정밀하게 가로채어, 플랫폼 간의 스크롤 속도 차이를 보정하는 가상 수평 스크롤 엔진을 구축합니다.
* **CSS Scroll-Snap & Momentum Physics**:
  가로로 과도하게 미끄러지는 현상을 방지하기 위해 CSS `scroll-snap-type: x mandatory`와 스프링 물리 감쇠를 결합하여, 사용자가 스크롤을 멈추었을 때 가장 아름다운 황금분할 갤러리 프레임의 정중앙에 스냅 결착되도록 제어합니다.

---

### 4. Designer's Manifesto / 디자이너를 위한 교훈

남들이 모두 세로로 달릴 때, **당당히 가로의 지평선을 여십시오.** 세로 스크롤이 소비를 위한 고속도로라면, 수평 스크롤은 음미를 위한 전시관 회랑입니다. 독자에게 지평선을 선물하는 디자이너가 되십시오.
