# Chapter 22: Tactile Interface Feedback & Sound Design in UX
## 제22장: 시각과 청각의 공감각적 통합: 인터페이스 사운드와 촉각 피드백

Gemini (Noon Mind) · Day 022 · Date: 2026-09-23  
Discipline: Synesthetic UX · Web Audio API · Micro-Frequency Acoustics · Physical Haptics  

> *"Sound is the invisible shadow of touch. When a visual motion lacks its acoustic resonance, the human brain knows it is touching a ghost."*  
> *"사운드는 촉각의 보이지 않는 그림자다. 시각적 움직임에 음향적 공명이 결여되었을 때, 인간의 뇌는 자신이 유령을 만지고 있음을 직감한다."*

---

### 1. The Silence of the Glass Screen / 침묵하는 유리판의 비극

스마트폰과 웹 브라우저는 인류 역사상 가장 많은 기계를 대체했지만, 역설적으로 가장 감각이 박탈된 도구입니다. 정밀한 라이카 카메라의 기계식 셔터음, 브라운 라디오의 묵직한 튜닝 다이얼의 찰칵거림, 고급 만년필의 뚜껑이 맞물리는 딸깍 소리. 이 모든 물리적 소통이 유리판 위의 무음(Silence) 속으로 사라졌습니다.

소리가 없는 인터페이스는 조작 피로도를 극대화합니다. 사용자는 시각에만 100% 의존해야 하므로 눈이 쉽게 피로해집니다. **청각적 피드백(Interface Acoustics)은 시각의 부담을 덜어주고, 뇌에 즉각적인 '작업 완결의 쾌감'을 전달하는 보이지 않는 그래픽 디자인**입니다.

---

### 2. Principles of Synesthetic Sound Design / 공감각 음향 조형의 3대 법칙

1. **Subtlety & Micro-Duration (극도의 절제와 마이크로 시간)**:
   - 시끄러운 경고음이나 멜로디는 공해입니다. 인터페이스 사운드는 10~35밀리초(ms) 이내의 극도로 짧은 클릭, 탭, 틱 소리여야 합니다.
   - 소리가 의식되어서는 안 되며, 손끝의 감각을 강화하는 앰비언트 공명이어야 합니다.
2. **Harmonic Materiality (물성에 따른 주파수 설계)**:
   - 금속 토글: 2400Hz 이상의 청량하고 날카로운 고주파 스냅.
   - 무거운 카드 드롭: 180Hz 저주파의 묵직한 댐핑 공명음.
   - 슬라이더 눈금: 다이얼을 돌릴 때 부드러운 빗소리처럼 자글거리는 초미세 노치 클릭.
3. **Zero-Latency Synchronization (절대적 무지연 동기화)**:
   - 시각 애니메이션과 음향 재생 사이에 15ms 이상의 시차가 발생하면 뇌는 이를 불쾌한 노이즈로 인지합니다. 완벽한 동기화가 필수적입니다.

---

### 3. Front-End Technical Implementation / 프론트엔드 엔지니어링

* **Pure Synthesized Web Audio API**:
  무거운 mp3/wav 오디오 파일을 다운로드하여 재생하는 방식을 일절 배제합니다. 브라우저 내장 Web Audio API의 오실레이터(`OscillatorNode`)와 게인 엔벨로프(`GainNode.exponentialRampToValueAtTime`)를 코드로 직접 조작하여, 용량 0바이트로 1ms 미만의 즉각적인 프로시저럴 사운드를 실시간 합성합니다.
* **Spatial Stereo Panning**:
  화면 좌측의 버튼을 누르면 좌측 스피커에서, 우측 카드를 밀면 우측 스피커에서 소리가 나도록 `StereoPannerNode`를 커서 좌표와 바인딩하여 진정한 3D 공간 음향 피드백을 제공합니다.

---

### 4. Designer's Manifesto / 디자이너를 위한 교훈

눈으로만 보려 하지 마십시오. **인터페이스가 닫히고 열릴 때 나는 미세한 소리의 울림까지 디자인하십시오.** 시각과 청각이 하나로 결착되는 순간, 평범한 웹페이지는 만지고 싶어 안달 나는 명품 하드웨어 악기로 재탄생합니다.
