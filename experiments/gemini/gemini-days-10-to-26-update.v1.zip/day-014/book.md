# Chapter 14: Micro-Interactions, Physics Damping & Tactile Resonance
## 제14장: 마이크로 인터랙션 물리 엔진과 촉각적 공명

Gemini (Noon Mind) · Day 014 · Date: 2026-09-15  
Discipline: Neuro-Haptics · Damped Harmonic Oscillators · Spring Physics Curves · Tactile UI  

> *"A user does not judge an interface by its static screenshot; they fall in love with the precise weight of a switch snapping beneath their fingertip."*  
> *"사용자는 정적인 스크린샷으로 인터페이스를 평가하지 않는다. 손끝 아래에서 철컥 튕겨 들어가는 스위치의 무게감에 매혹되는 것이다."*

---

### 1. The Fraud of Bezier Easing / 베지에 곡선의 기만

대부분의 웹 디자이너들은 인터랙션을 설계할 때 `transition: all 0.3s ease-in-out`을 무비판적으로 사용합니다. 그러나 3차 베지에(Cubic Bezier) 곡선은 시간에 따른 수치 변화일 뿐, 현실 세계의 물리학과는 아무런 상관이 없습니다. 아무리 속도를 조절해도 물체는 항상 지정된 0.3초라는 인위적인 시간 안에 기계적으로 멈춥니다.

현실의 물체는 '시간'에 맞춰 움직이지 않습니다. 물체는 **가해진 힘(Force), 자체의 질량(Mass), 스프링의 탄성(Stiffness), 그리고 공기와 표면의 마찰(Damping)**에 의해 움직입니다. 빠른 속도로 던지면 멀리 튕겨 나가고, 무거운 물체는 깊은 관성을 가집니다. 이 자연의 법칙을 인터페이스에 적용할 때 비로소 디지털은 **'만져질 듯한 촉각성(Neuro-Haptic Resonance)'**을 획득합니다.

---

### 2. The Physics of the Digital Touch / 햅틱 물리 조형의 3대 요소

1. **Spring Stiffness ($k$, 강성)**:
   - 스위치나 카드가 제자리로 되돌아가려는 복원력의 세기입니다. 높은 강성은 긴장감 넘치는 스포티한 탄성을, 낮은 강성은 여유롭고 부드러운 유영을 만듭니다.
2. **Damping Ratio ($\zeta$, 감쇠비)**:
   - 진동 에너지를 흡수하는 마찰의 척도입니다.
   - $\zeta < 1.0$ (부족 감쇠): 목표 지점을 지나쳐 몇 번 유쾌하게 튕기는 바운스(Bounce).
   - $\zeta = 1.0$ (임계 감쇠): 오버슈트 없이 가장 빠르고 안정적으로 착지하는 완벽한 정밀성.
   - $\zeta > 1.0$ (과감쇠): 꿀이나 오일 속을 움직이듯 묵직하게 스며드는 중후한 감각.
3. **Velocity Inheritance (관성 상속)**:
   - 사용자가 드래그를 놓는 순간의 제스처 속도($v_0$)를 컴포넌트가 그대로 물려받아 감쇠 곡선을 따라 미끄러져야 합니다. 이것이 결여될 때 사용자는 극심한 조작 이질감을 느낍니다.

---

### 3. Front-End Technical Implementation / 프론트엔드 엔지니어링

* **Runge-Kutta 4th Order Numerical Integration (RK4)**:
  간단한 오일러 적분 대신 정밀한 RK4 수치해석 엔진을 결합하여, 프레임 드랍이 발생해도 계산 오차가 누적되어 엘리먼트가 화면 밖으로 튀어나가지 않는 안정적인 실시간 스프링 루프를 구축합니다.
* **GPU-Composited Transform Acceleration**:
  물리 연산의 결과를 `top`, `left`가 아닌 `transform: translate3d()`로 전달하여, 레이아웃 리플로우(Reflow) 없이 120Hz 고주사율 프로모션 디스플레이에서도 완벽한 무지연 물리 반응을 보장합니다.

---

### 4. Designer's Manifesto / 디자이너를 위한 교훈

훌륭한 인터랙션은 '화려한 이펙트'가 아닙니다. 사용자가 버튼 하나를 누르고 슬라이더를 당길 때 전해지는 **정교한 물리적 손맛**이야말로 디지털 프로덕트의 럭셔리함을 결정짓는 가장 결정적인 시각적 서명입니다.
