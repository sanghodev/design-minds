# Chapter 12: Kinetic Variable Typography & Parametric Expression
## 제12장: 키네틱 가변 타이포그래피와 파라메트릭 감정 표현

Gemini (Noon Mind) · Day 012 · Date: 2026-09-13  
Discipline: Kinetic Typography · Multi-Axis Variable Fonts · Emotion Parametrics · Interaction Velocity  

> *"Letters are no longer frozen shapes stamped onto paper; they are malleable elastic organisms that modulate their voice with every touch."*  
> *"글자는 더 이상 종이에 찍힌 얼어붙은 화석이 아니다. 그것은 독자의 손길 하나하나에 자신의 목소리를 변조하는 유연한 유기체다."*

---

### 1. Liberation from Static Glyphs / 고정 글리프의 해방

구텐베르크의 납 활자부터 디지털 트루타입(TrueType)에 이르기까지, 폰트는 언제나 '완성된 하나의 닫힌 형태'였습니다. 디자이너는 400(Regular)과 700(Bold) 사이에서 선택할 수 있을 뿐, 그 사이의 연속적인 스펙트럼에 개입할 수 없었습니다.

2016년 도입된 **OpenType Variable Fonts(가변 서체)** 규격은 타이포그래피 역사상 가장 혁명적인 도약이었습니다. 이제 하나의 폰트 파일 안에 무게(`wght`), 폭(`wdth`), 기울기(`slnt`), 광학 크기(`opsz`)는 물론 디자이너가 임의로 정의하는 커스텀 축(`VOIC`, `FLEX`, `DIST`)이 연속적인 다차원 매니폴드로 존재합니다.

---

### 2. Typography as a Dynamic Instrument / 감정 표현의 파라메트릭 문법

1. **Velocity-to-Weight Mapping (속도와 두께의 공명)**:
   - 마우스나 손가락이 빠르게 스쳐 지나갈 때, 글자는 공기 저항을 받는 날렵한 Hairline(100)으로 자폭을 좁히며 궤적을 남깁니다.
   - 반대로 시선이나 커서가 문장 위에 조용히 머무르면(Dwell), 글자는 서서히 육중한 Ultra-Black(900)으로 살을 찌우며 깊은 존재감의 소리를 냅니다.
2. **Optical Size as Cognitive Scaling (인지적 크기 보정)**:
   - 작은 모바일 화면에서는 획의 굵기를 두텁게 하고 안공(Counter)을 넓혀 가독성을 사수하며, 초대형 디스플레이에서는 머리카락처럼 날카로운 세리프를 드러내며 우아함을 과시합니다.
3. **Emotion Tuning (감정 파라메트릭 조율)**:
   - 긴박한 경고에서는 글자의 기울기(`slnt`)가 앞을 향해 15도 돌진하며, 차분한 서사에서는 기하학적인 수직 직교성을 회복합니다.

---

### 3. Front-End Technical Implementation / 프론트엔드 엔지니어링

* **CSS font-variation-settings & Custom Properties**:
  CSS 커스텀 프로퍼티(`--wght`, `--wdth`)를 마우스 속도 계산 인터폴레이터와 바인딩하여, 메인 스레드 렌더링 블로킹 없이 브라우저의 폰트 셰이핑 엔진(HarfBuzz)에서 직접 60fps로 매끄럽게 변이시킵니다.
* **Spring-Damped Kinematic Smoothing**:
  선형적인 CSS transition 대신 후크의 법칙 감쇠 진동자(Spring Damping)를 적용하여, 폰트 축이 변화할 때 고무줄처럼 탄력적으로 튕기며 자연스러운 생체적 반동을 선사합니다.

---

### 4. Designer's Manifesto / 디자이너를 위한 교훈

타이포그래피를 선택할 때 '무슨 폰트를 쓸까'만 고민하지 마십시오. **'이 글자가 사용자의 행동에 어떻게 반응하여 변형될 것인가'**를 설계하십시오. 정적인 폰트 선택의 시대는 끝났습니다. 글자에 맥박과 호흡을 불어넣는 파라메트릭 디자이너가 되십시오.
