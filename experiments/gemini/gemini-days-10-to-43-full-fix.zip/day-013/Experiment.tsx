"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";

interface StudioCard {
  id: string;
  tag: string;
  title: string;
  ko: string;
  desc: string;
}

const STUDIO_CARDS: StudioCard[] = [
  {
    "id": "01",
    "tag": "RAW MATERIALITY",
    "title": "Exposed DOM Skeleton",
    "ko": "노출 콘크리트 그리드 골조",
    "desc": "화려한 장식과 뿌연 그림자를 걷어내고 HTML/CSS의 구조적 뼈대를 정직하게 드러냅니다."
  },
  {
    "id": "02",
    "tag": "ZERO-BLUR SHADOW",
    "title": "Architectural Relief",
    "ko": "무블러 기하학적 단차",
    "desc": "가우시안 블러 없는 날카로운 블랙 하드 섀도우로 명확한 물리적 층위를 형성합니다."
  },
  {
    "id": "03",
    "tag": "HIGH CONTRAST",
    "title": "Ink & Paper Honesty",
    "ko": "잉크와 종이의 물성 대비",
    "desc": "피로도를 낮추는 따뜻한 미색 지류 표면 위에 순수한 먹색 활자를 강렬하게 각인합니다."
  },
  {
    "id": "04",
    "tag": "SUBTRACTIVE CLARITY",
    "title": "Radical Reduction",
    "ko": "비본질적 장식의 완전 제거",
    "desc": "불필요한 UI 치장을 덜어낼수록 핵심 메시지의 전달 속도와 권위가 배가됩니다."
  }
];
const MODES: string[] = ["Exposed Hairline Grid", "High-Contrast Constructivist", "Zero-Ornament Terminal"];

export default function SubtractiveBrutalismStudio() {
  const [param1, setParam1] = useState<number>(64);
  const [param2, setParam2] = useState<number>(48);
  const [activeMode, setActiveMode] = useState<number>(0);
  const [selectedCard, setSelectedCard] = useState<string>("01");
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [pointer, setPointer] = useState<{ x: number; y: number; vx: number; vy: number }>({ x: 0.5, y: 0.5, vx: 0, vy: 0 });
  const [pulseCount, setPulseCount] = useState<number>(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const lastPointerRef = useRef<{ x: number; y: number; t: number }>({ x: 0.5, y: 0.5, t: 0 });

  const playTactileClick = useCallback((freq = 520, duration = 0.045) => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") ctx.resume();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.45, now + duration);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + duration + 0.01);
    } catch {
      // Ignore audio restriction before interaction
    }
  }, [soundEnabled]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const render = () => {
      phase += 0.018 * (0.4 + param1 / 60);
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const gridStep = Math.max(24, Math.floor(64 - param1 * 0.25));
      ctx.strokeStyle = "rgba(0,0,0,0.12)";
      ctx.lineWidth = 1;

      for (let x = 0; x <= w; x += gridStep) {
        const dx = x - pointer.x * w;
        const bend = Math.sin(phase + x * 0.01) * (param2 * 0.18) * Math.exp(-(dx * dx) / 45000);
        ctx.beginPath();
        ctx.moveTo(x + bend, 0);
        ctx.lineTo(x - bend, h);
        ctx.stroke();
      }

      for (let y = 0; y <= h; y += gridStep) {
        const dy = y - pointer.y * h;
        const bend = Math.cos(phase + y * 0.015) * (param2 * 0.18) * Math.exp(-(dy * dy) / 25000);
        ctx.beginPath();
        ctx.moveTo(0, y + bend);
        ctx.lineTo(w, y - bend);
        ctx.stroke();
      }

      const px = pointer.x * w;
      const py = pointer.y * h;
      const ringCount = 4 + activeMode * 2;
      for (let i = 1; i <= ringCount; i++) {
        const radius = i * (18 + param1 * 0.35) + Math.sin(phase * 2 + i) * 6;
        ctx.beginPath();
        ctx.arc(px, py, Math.max(4, radius), 0, Math.PI * 2);
        ctx.strokeStyle = i % 2 === 0 ? "#FF330066" : "#11111155";
        ctx.lineWidth = i === 1 ? 2.2 : 1.2;
        ctx.stroke();
      }

      const anchors = [
        [w * 0.15, h * 0.25],
        [w * 0.85, h * 0.25],
        [w * 0.15, h * 0.75],
        [w * 0.85, h * 0.75],
      ];
      anchors.forEach(([ax, ay], idx) => {
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        const cx = (ax + px) * 0.5 + Math.sin(phase + idx) * param2 * 0.4;
        const cy = (ay + py) * 0.5 + Math.cos(phase + idx) * param2 * 0.4;
        ctx.quadraticCurveTo(cx, cy, px, py);
        ctx.strokeStyle = "#FF330044";
        ctx.lineWidth = 1.2;
        ctx.stroke();

        ctx.fillStyle = "#FF3300";
        ctx.beginPath();
        ctx.arc(ax, ay, 4, 0, Math.PI * 2);
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [param1, param2, activeMode, pointer]);

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const ny = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    const now = performance.now();
    const dt = Math.max(16, now - lastPointerRef.current.t);
    const vx = Math.round(((nx - lastPointerRef.current.x) / dt) * 10000);
    const vy = Math.round(((ny - lastPointerRef.current.y) / dt) * 10000);
    lastPointerRef.current = { x: nx, y: ny, t: now };
    setPointer({ x: nx, y: ny, vx, vy });
  };

  const dynamicWeight = Math.min(900, Math.max(300, Math.round(350 + param1 * 4.5 + Math.hypot(pointer.vx, pointer.vy) * 12)));
  const dynamicTracking = (-0.03 + (param2 / 100) * 0.08).toFixed(3);
  const tiltX = ((pointer.y - 0.5) * (param2 * 0.22)).toFixed(2);
  const tiltY = ((pointer.x - 0.5) * -(param2 * 0.22)).toFixed(2);

  return (
    <div
      onPointerMove={handlePointerMove}
      style={{
        backgroundColor: "#F2EFE9",
        color: "#0D0D0D",
        minHeight: "100vh",
      }}
      className="relative w-full overflow-x-hidden select-none font-sans p-6 md:p-12 flex flex-col justify-between gap-8"
    >
      <header
        style={{ borderColor: "rgba(0,0,0,0.12)" }}
        className="relative z-20 flex flex-wrap items-center justify-between gap-4 border-b pb-5"
      >
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              style={{ backgroundColor: "#FF3300", color: "#FFFFFF" }}
              className="px-3 py-1 rounded-full font-mono text-xs font-bold tracking-wider uppercase transition-transform hover:scale-105"
            >
              ← DM-013
            </Link>
            <span className="font-mono text-xs uppercase tracking-widest opacity-70">
              DAY 013 · 2026-09-14 · GEMINI 4 ARGON
            </span>
          </div>
          <h1
            style={{
              fontWeight: dynamicWeight,
              letterSpacing: `${dynamicTracking}em`,
            }}
            className="text-2xl md:text-5xl uppercase tracking-tight transition-all duration-75 mt-2"
          >
            Subtractive Brutalism & Raw Materiality
          </h1>
          <p style={{ color: "rgba(17,19,24,0.65)" }} className="text-xs md:text-sm font-mono">
            감산적 브루탈리즘과 디지털 로우 머티리얼리티 — Neo-Brutalism · Digital Honesty · Truth-to-Screen Materials · Anti-Corporate Minimalism
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <button
            onClick={() => {
              setSoundEnabled(!soundEnabled);
              playTactileClick(660, 0.05);
            }}
            style={{ borderColor: "rgba(0,0,0,0.12)", backgroundColor: "#FFFFFF" }}
            className="px-3.5 py-2 rounded-xl border font-bold uppercase transition-all hover:scale-105"
          >
            {soundEnabled ? "🔊 HAPTIC AUDIO ON" : "🔇 AUDIO MUTED"}
          </button>
          <button
            onClick={() => {
              setParam1(64);
              setParam2(48);
              setActiveMode(0);
              setPulseCount((c) => c + 1);
              playTactileClick(880, 0.06);
            }}
            style={{ borderColor: "#FF3300", color: "#FF3300" }}
            className="px-3.5 py-2 rounded-xl border font-bold uppercase transition-all hover:scale-105"
          >
            ↺ SWISS EQUILIBRIUM RESET
          </button>
        </div>
      </header>

      <main className="relative z-20 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div
          style={{
            backgroundColor: "#FFFFFF",
            borderColor: "rgba(0,0,0,0.12)",
            transform: `perspective(1200px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`,
          }}
          className="lg:col-span-7 relative rounded-3xl border p-6 md:p-8 flex flex-col justify-between overflow-hidden min-h-[420px] transition-transform duration-75 shadow-xl"
        >
          <canvas
            ref={canvasRef}
            width={760}
            height={420}
            className="absolute inset-0 w-full h-full pointer-events-none opacity-85"
          />

          <div className="relative z-10 flex flex-wrap items-center justify-between gap-2">
            <span
              style={{ backgroundColor: "#FF330022", color: "#FF3300", borderColor: "#FF330055" }}
              className="px-3 py-1 rounded-full border font-mono text-xs font-bold uppercase tracking-wider"
            >
              ACTIVE MODE: {MODES[activeMode]}
            </span>
            <span className="font-mono text-xs opacity-70">
              CURSOR: ({(pointer.x * 100).toFixed(0)}%, {(pointer.y * 100).toFixed(0)}%) · VEL: {Math.hypot(pointer.vx, pointer.vy).toFixed(1)}
            </span>
          </div>

          <div
            onClick={() => {
              setPulseCount((c) => c + 1);
              playTactileClick(587.33, 0.07);
            }}
            className="relative z-10 my-auto py-10 text-center cursor-pointer group"
          >
            <div className="font-mono text-[11px] uppercase tracking-[0.25em] opacity-60 mb-2">
              CLICK OR GLIDE POINTER TO EXCITE FIELD · IMPULSE #{pulseCount}
            </div>
            <div
              style={{
                fontWeight: dynamicWeight,
                letterSpacing: `${dynamicTracking}em`,
                color: "#0D0D0D",
              }}
              className="text-3xl md:text-6xl uppercase tracking-tight leading-none transition-all duration-75 group-hover:scale-[1.02]"
            >
              Subtractive Brutalism & Raw Materiality
            </div>
            <p
              style={{ color: "rgba(17,19,24,0.65)" }}
              className="max-w-xl mx-auto mt-4 text-xs md:text-sm leading-relaxed"
            >
              실리콘밸리 기업들이 양산해 낸 푹신한 파스텔톤 그라디언트와 둥글둥글한 모서리라는 가식적인 세련미를 전면 거부함. 콘크리트의 날것 그대로를 드러내는 브루탈리즘(Béton Brut)의 건축 철학을 디지털 스크린에 이식하여, 블러가 전혀 없는 단단한 4px 블랙 외곽선, 하드 캐스트 섀도우, 100% 모노스페이스 데이터 태그를 통해 화면이라는 매체의 물질적 진실을 직시하는 급진적 시각 디자인 탐구.
            </p>
          </div>

          <div
            style={{ borderColor: "rgba(0,0,0,0.12)" }}
            className="relative z-10 pt-4 border-t flex flex-wrap items-center justify-between gap-2 font-mono text-xs opacity-80"
          >
            <span>FORMULA: Shadow(x,y) = Offset(Δx, Δy) · Blur(0px) · Opacity(1.0)</span>
            <span style={{ color: "#FF3300" }} className="font-bold">
              WGHT {dynamicWeight} · TRACK {dynamicTracking}em
            </span>
          </div>
        </div>

        <div
          style={{ backgroundColor: "#FFFFFF", borderColor: "rgba(0,0,0,0.12)" }}
          className="lg:col-span-5 rounded-3xl border p-6 md:p-8 flex flex-col justify-between gap-6 shadow-xl"
        >
          <div className="space-y-5">
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: "rgba(0,0,0,0.12)" }}>
              <span className="font-mono text-xs font-bold uppercase tracking-wider">
                PARAMETRIC CONTROL DECK (실시간 조형 제어)
              </span>
              <span style={{ color: "#FF3300" }} className="font-mono text-xs font-bold">
                60 FPS LIVE
              </span>
            </div>

            <div className="space-y-2">
              <label className="font-mono text-xs opacity-75 block">
                1. ARCHITECTURAL PRESET MODE (조형 프리셋)
              </label>
              <div className="grid grid-cols-1 gap-2">
                {MODES.map((m, idx) => (
                  <button
                    key={m}
                    onClick={() => {
                      setActiveMode(idx);
                      setParam1(45 + idx * 22);
                      setParam2(35 + idx * 25);
                      playTactileClick(440 + idx * 110, 0.05);
                    }}
                    style={{
                      borderColor: activeMode === idx ? "#FF3300" : "rgba(0,0,0,0.12)",
                      backgroundColor: activeMode === idx ? "#FF330018" : "transparent",
                    }}
                    className="px-4 py-2.5 rounded-xl border text-left font-mono text-xs flex items-center justify-between transition-all"
                  >
                    <span className="font-bold">{idx + 1}. {m}</span>
                    <span style={{ color: "#FF3300" }}>{activeMode === idx ? "● ACTIVE" : "SELECT"}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between font-mono text-xs">
                <span>Structural Border Gauge (구조선 두께 규격)</span>
                <span style={{ color: "#FF3300" }} className="font-bold">{param1}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                value={param1}
                onChange={(e) => {
                  setParam1(Number(e.target.value));
                  playTactileClick(380 + Number(e.target.value) * 3, 0.025);
                }}
                className="w-full cursor-pointer accent-rose-500"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between font-mono text-xs">
                <span>Hard Cast Shadow Offset (무블러 그림자 변위)</span>
                <span style={{ color: "#111111" }} className="font-bold">{param2}%</span>
              </div>
              <input
                type="range"
                min={5}
                max={100}
                value={param2}
                onChange={(e) => {
                  setParam2(Number(e.target.value));
                  playTactileClick(500 + Number(e.target.value) * 4, 0.025);
                }}
                className="w-full cursor-pointer accent-cyan-400"
              />
            </div>
          </div>

          <div
            style={{ borderColor: "rgba(0,0,0,0.12)", backgroundColor: "#F2EFE9" }}
            className="p-4 rounded-2xl border space-y-2 text-xs leading-relaxed"
          >
            <div style={{ color: "#FF3300" }} className="font-mono font-bold uppercase">
              HYPOTHESIS & INSIGHT (핵심 연구 가설 및 통찰)
            </div>
            <p className="opacity-85">Can digital brutalism transcend superficial kitsch by formulating an uncompromising philosophy of 'digital honesty'—stripping away fake skeumorphic lighting, corporate pastels, and blurred shadows in favor of hard zero-blur geometry, monospaced typography, and structural truth-to-materials?</p>
            <p style={{ color: "rgba(17,19,24,0.65)" }} className="pt-1 border-t">
              장식을 덜어내고 거친 뼈대를 그대로 드러냈을 때, 역설적으로 가장 현대적이고 강렬한 시각적 권위와 지적 매혹이 발생함을 확인.
            </p>
          </div>
        </div>
      </main>

      <section className="relative z-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {STUDIO_CARDS.map((card, i) => {
          const isSel = selectedCard === card.id;
          return (
            <div
              key={card.id}
              onClick={() => {
                setSelectedCard(card.id);
                setParam1(40 + i * 18);
                playTactileClick(520 + i * 90, 0.05);
              }}
              style={{
                backgroundColor: "#FFFFFF",
                borderColor: isSel ? "#FF3300" : "rgba(0,0,0,0.12)",
              }}
              className="p-5 rounded-2xl border cursor-pointer transition-all duration-200 hover:-translate-y-1 flex flex-col justify-between gap-4 shadow-md"
            >
              <div>
                <div className="flex items-center justify-between font-mono text-[11px] mb-2">
                  <span style={{ color: "#FF3300" }} className="font-bold uppercase">
                    {card.id} // {card.tag}
                  </span>
                  <span className="opacity-50">{isSel ? "★ FOCUSED" : "CLICK"}</span>
                </div>
                <h3 className="text-lg font-extrabold tracking-tight">{card.title}</h3>
                <div className="text-xs font-semibold opacity-80 mt-0.5">{card.ko}</div>
                <p style={{ color: "rgba(17,19,24,0.65)" }} className="text-xs leading-relaxed mt-2">
                  {card.desc}
                </p>
              </div>
              <div
                style={{ borderColor: "rgba(0,0,0,0.12)" }}
                className="pt-2.5 border-t flex items-center justify-between font-mono text-[10px] opacity-65"
              >
                <span>SWISS MODULE {card.id}</span>
                <span>INTERACTIVE LOCK</span>
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}
